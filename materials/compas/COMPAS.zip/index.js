var scipy = require("scipy");
var pandas = require("pandas-js");
var jsregression = require("js-regression");

module.exports = {
    scipy: scipy,
    pandas: pandas,
    jsregression: jsregression,
}